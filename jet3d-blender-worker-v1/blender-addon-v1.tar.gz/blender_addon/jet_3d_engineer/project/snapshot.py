from pathlib import Path

import bpy


def create_blend_snapshot(path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(path), copy=True)
    return path


def restore_blend_snapshot(path: Path) -> None:
    bpy.ops.wm.open_mainfile(filepath=str(path))
