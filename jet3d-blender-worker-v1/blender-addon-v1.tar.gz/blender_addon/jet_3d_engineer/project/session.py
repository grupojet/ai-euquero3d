import json
from dataclasses import dataclass


@dataclass
class SessionState:
    project_id: str = ""
    revision: int = 0
    project_root: str = ""


def sync_project_properties(props, state: dict) -> None:
    props.project_id = state.get("project_id", props.project_id)
    props.project_name = state.get("project_name", props.project_name)
    props.printer_profile = state.get("printer_profile", props.printer_profile)
    props.material_profile = state.get("material_profile", props.material_profile)
    props.current_revision = int(state.get("revision", props.current_revision))
    props.revision_history_json = json.dumps(state.get("revision_history", []))
    props.fits_json = json.dumps(state.get("fits", []))
