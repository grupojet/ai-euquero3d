from collections.abc import Callable
from typing import TypeVar

T = TypeVar("T")


def run_with_rollback(action: Callable[[], T], rollback: Callable[[], None]) -> T:
    try:
        return action()
    except Exception:
        rollback()
        raise
