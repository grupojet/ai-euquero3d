import json

import bpy


def _safe_json(value: str, default):
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return default


class JET3D_PT_main(bpy.types.Panel):
    bl_label = "JET 3D Engineer"
    bl_idname = "JET3D_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "JET 3D"

    def draw(self, context):
        layout = self.layout
        props = context.scene.jet3d
        layout.prop(props, "service_url")
        layout.prop(props, "api_token")
        layout.operator("jet3d.reconnect", icon="LINKED")
        layout.prop(props, "project_name")
        layout.prop(props, "printer_profile")
        layout.prop(props, "material_profile")
        layout.operator("jet3d.create_project", icon="FILE_NEW")
        layout.prop(props, "project_id")
        layout.operator("jet3d.open_project", icon="FILE_FOLDER")
        layout.separator()
        layout.prop(props, "instruction")
        layout.operator("jet3d.interpret", icon="OUTLINER_OB_LIGHT")

        proposal = _safe_json(props.proposal_json, {})
        if proposal:
            box = layout.box()
            box.label(text=f"Preflight r{proposal.get('proposed_revision', 0):03d}")
            changes = proposal.get("parameter_changes", {})
            if changes:
                for key, value in sorted(changes.items()):
                    box.label(text=f"{key}: {value}")
            parts = proposal.get("affected_parts", [])
            if parts:
                box.label(text="Parts: " + ", ".join(parts))
            if proposal.get("manufacturing_critical"):
                box.label(text="Manufacturing-critical change", icon="ERROR")

        layout.operator("jet3d.apply_revision", icon="CHECKMARK")
        layout.operator("jet3d.rebuild_current", icon="FILE_REFRESH")
        layout.prop(props, "confirm_manual_override")
        layout.operator("jet3d.validate", icon="CHECKMARK")
        for item in props.warning_acknowledgements:
            layout.prop(item, "acknowledged", text=f"Acknowledge {item.code}")
        layout.prop(props, "export_version")
        layout.operator("jet3d.export", icon="EXPORT")
        layout.label(text=f"Revision: {props.current_revision}")
        layout.label(text=props.status_message)

        history = _safe_json(props.revision_history_json, [])
        if history:
            box = layout.box()
            box.label(text="Revision history")
            for entry in history[-5:]:
                revision = int(entry.get("revision", 0))
                instruction = str(entry.get("instruction", ""))
                box.label(text=f"r{revision:03d}: {instruction[:42]}")

        fits = _safe_json(props.fits_json, [])
        if fits:
            box = layout.box()
            box.label(text="Applied fit compensation")
            for fit in fits:
                fit_type = fit.get("type", "fit")
                nominal = fit.get("nominal_mm", "?")
                compensation = fit.get("compensation_mm", "?")
                box.label(text=f"{fit_type}: {nominal} mm / {compensation:+g} mm" if isinstance(compensation, (int, float)) else f"{fit_type}: {nominal} mm / {compensation}")

        if props.export_result_json and props.export_result_json != "{}":
            result = _safe_json(props.export_result_json, {})
            layout.label(text=result.get("report_path", ""))
