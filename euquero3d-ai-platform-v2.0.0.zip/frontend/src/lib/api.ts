const API_BASE = process.env.NEXT_PUBLIC_API_URL || '/api/v1';

export interface GenerateRequest {
  prompt?: string;
  image_url?: string;
  engine: 'hunyuan3d' | 'triposr';
  material: string;
  layer_height: number;
}

export interface JobResponse {
  job_id: string;
  status: string;
  progress?: {
    status: string;
    stage: string;
    progress: number;
    message: string;
    outputs?: Record<string, string>;
    metrics?: {
      volume_cm3: number;
      filament_grams: number;
      print_time_hours: number;
      print_time_formatted: string;
      cost_material: number;
      cost_machine: number;
      cost_total: number;
      price_sell: number;
    };
    mesh_info?: {
      faces: number;
      vertices: number;
      watertight: boolean;
    };
  };
}

export async function createTextTo3D(data: Omit<GenerateRequest, 'image_url'>): Promise<JobResponse> {
  const res = await fetch(`${API_BASE}/jobs/text-to-3d`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function createImageTo3D(data: Omit<GenerateRequest, 'prompt'>): Promise<JobResponse> {
  const res = await fetch(`${API_BASE}/jobs/image-to-3d`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function uploadImage(file: File): Promise<{ url: string; object_name: string }> {
  const formData = new FormData();
  formData.append('file', file);

  const res = await fetch(`${API_BASE}/upload/image`, {
    method: 'POST',
    body: formData,
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function getJobStatus(jobId: string): Promise<JobResponse> {
  const res = await fetch(`${API_BASE}/jobs/${jobId}`);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}
