'use client';

import { Cpu, Zap } from 'lucide-react';

export default function Header() {
  return (
    <header className="relative border-b border-white/5 overflow-hidden">
      {/* Top gradient line */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-holo-gradient" />

      <div className="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
        <div className="flex items-center gap-4">
          {/* Wireframe Cube Logo */}
          <svg width="44" height="44" viewBox="0 0 44 44" fill="none" className="flex-shrink-0">
            <path
              d="M22 4L40 14V32L22 42L4 32V14L22 4Z"
              stroke="url(#cubeGrad)"
              strokeWidth="1.5"
              fill="none"
            />
            <path
              d="M22 4V22M22 22L40 32M22 22L4 32"
              stroke="url(#cubeGrad)"
              strokeWidth="1"
              opacity="0.5"
            />
            <path
              d="M4 14L22 22L40 14"
              stroke="#C6F432"
              strokeWidth="1"
              opacity="0.7"
            />
            <defs>
              <linearGradient id="cubeGrad" x1="4" y1="4" x2="40" y2="42">
                <stop stopColor="#7C3AED" />
                <stop offset="1" stopColor="#22D3EE" />
              </linearGradient>
            </defs>
          </svg>

          <div>
            <h1 className="text-2xl font-bold tracking-tight">
              <span className="bg-holo-gradient bg-clip-text text-transparent">euquero</span>
              <span className="text-neon-lime">3d</span>
            </h1>
            <p className="text-[11px] text-cyber-violet font-mono tracking-widest uppercase">
              AI Platform // v2.0.0
            </p>
          </div>
        </div>

        <div className="flex items-center gap-5">
          <div className="hidden sm:flex items-center gap-2 bg-deep-space-2 border border-white/5 px-4 py-2 rounded-full">
            <div className="w-2 h-2 rounded-full bg-neon-lime animate-pulse-glow" />
            <span className="text-xs text-gray-400 font-mono">GPU ONLINE</span>
          </div>

          <div className="flex items-center gap-2 text-xs text-gray-500 font-mono">
            <Cpu size={14} className="text-electric-cyan" />
            <span>print(you)</span>
          </div>
        </div>
      </div>
    </header>
  );
}
