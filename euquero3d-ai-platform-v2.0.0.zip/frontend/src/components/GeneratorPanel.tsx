'use client';

import { useState, useCallback } from 'react';
import { Upload, FileText, Image as ImageIcon, Sparkles, ChevronDown } from 'lucide-react';
import { createTextTo3D, createImageTo3D, uploadImage } from '@/lib/api';

interface GeneratorPanelProps {
  onJobCreated: (jobId: string) => void;
}

const MATERIALS = [
  { key: 'pla', name: 'PLA', price: 85, desc: 'Standard', color: '#C6F432' },
  { key: 'abs', name: 'ABS', price: 95, desc: 'Resistant', color: '#22D3EE' },
  { key: 'petg', name: 'PETG', price: 110, desc: 'Durable', color: '#7C3AED' },
  { key: 'tpu', name: 'TPU', price: 150, desc: 'Flexible', color: '#E5E5F0' },
  { key: 'resina', name: 'Resina', price: 280, desc: 'High Res', color: '#22D3EE' },
];

const ENGINES = [
  { key: 'hunyuan3d', name: 'Hunyuan3D 2.1', desc: 'Melhor qualidade • 24GB VRAM', badge: 'RECOMMENDED' },
  { key: 'triposr', name: 'TripoSR', desc: 'Ultra rápido • 6GB VRAM', badge: 'FAST' },
];

export default function GeneratorPanel({ onJobCreated }: GeneratorPanelProps) {
  const [inputMode, setInputMode] = useState<'text' | 'image'>('text');
  const [prompt, setPrompt] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [engine, setEngine] = useState('hunyuan3d');
  const [material, setMaterial] = useState('pla');
  const [layerHeight, setLayerHeight] = useState(0.2);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError('Apenas imagens (JPG, PNG, WEBP)');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setError('Máximo 10MB');
      return;
    }

    setSelectedFile(file);
    setPreviewUrl(URL.createObjectURL(file));
    setError('');
  }, []);

  const handleGenerate = async () => {
    setError('');
    setIsLoading(true);

    try {
      if (inputMode === 'text') {
        if (!prompt.trim()) {
          setError('Digite um prompt descrevendo o objeto');
          setIsLoading(false);
          return;
        }

        const res = await createTextTo3D({
          prompt: prompt.trim(),
          engine: engine as 'hunyuan3d' | 'triposr',
          material,
          layer_height: layerHeight,
        });

        onJobCreated(res.job_id);
      } else {
        if (!selectedFile) {
          setError('Selecione uma imagem primeiro');
          setIsLoading(false);
          return;
        }

        // Upload image first
        const uploadRes = await uploadImage(selectedFile);

        const res = await createImageTo3D({
          image_url: uploadRes.url,
          engine: engine as 'hunyuan3d' | 'triposr',
          material,
          layer_height: layerHeight,
        });

        onJobCreated(res.job_id);
      }
    } catch (err: any) {
      setError(err.message || 'Erro ao criar job');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-deep-space-2 border border-white/5 rounded-xl p-6 relative hud-corner">
      <div className="font-mono text-[11px] text-cyber-violet tracking-widest uppercase mb-5">
        INPUT_MODULE // v1.0
      </div>

      {/* Input Mode Toggle */}
      <div className="mb-5">
        <label className="block text-xs text-gray-400 font-mono mb-2">modo_de_entrada</label>
        <div className="flex gap-2">
          <button
            onClick={() => setInputMode('text')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg border font-mono text-sm font-semibold transition-all ${
              inputMode === 'text'
                ? 'border-neon-lime bg-neon-lime/10 text-neon-lime'
                : 'border-white/5 bg-transparent text-gray-500 hover:text-gray-300'
            }`}
          >
            <FileText size={16} />
            [TXT] TEXTO
          </button>
          <button
            onClick={() => setInputMode('image')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg border font-mono text-sm font-semibold transition-all ${
              inputMode === 'image'
                ? 'border-neon-lime bg-neon-lime/10 text-neon-lime'
                : 'border-white/5 bg-transparent text-gray-500 hover:text-gray-300'
            }`}
          >
            <ImageIcon size={16} />
            [IMG] IMAGEM
          </button>
        </div>
      </div>

      {/* Text Input */}
      {inputMode === 'text' && (
        <div className="mb-5">
          <label className="block text-xs text-gray-400 font-mono mb-2">
            prompt // descreva o objeto
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={4}
            className="w-full bg-deep-space border border-white/10 rounded-lg p-4 text-sm text-ghost-white placeholder-gray-600 resize-none focus:outline-none focus:border-cyber-violet transition-colors font-mono"
            placeholder="Suporte para fonte ATX, estilo industrial cyberpunk, com ventilação mesh hexagonal, 4 furos M4, material PETG, altura 80mm..."
          />
          <div className="mt-1 text-[10px] text-gray-600 font-mono">
            lang: pt-BR | max_tokens: 512
          </div>
        </div>
      )}

      {/* Image Input */}
      {inputMode === 'image' && (
        <div className="mb-5">
          <label className="block text-xs text-gray-400 font-mono mb-2">
            upload // imagem de referência
          </label>
          <div
            onClick={() => document.getElementById('file-upload')?.click()}
            className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all ${
              previewUrl
                ? 'border-neon-lime/30 bg-neon-lime/5'
                : 'border-white/10 hover:border-white/20 bg-deep-space'
            }`}
          >
            <input
              id="file-upload"
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
            />

            {previewUrl ? (
              <div className="relative">
                <img
                  src={previewUrl}
                  alt="Preview"
                  className="max-h-48 mx-auto rounded-lg object-contain"
                />
                <p className="mt-2 text-xs text-neon-lime font-mono">
                  [OK] {selectedFile?.name}
                </p>
              </div>
            ) : (
              <>
                <Upload size={28} className="mx-auto mb-2 text-gray-500" />
                <p className="text-sm text-gray-500 font-mono">
                  drop_zone // clique para upload
                </p>
                <p className="text-[10px] text-gray-600 mt-1 font-mono">
                  JPG, PNG, WEBP • max 10MB
                </p>
              </>
            )}
          </div>
        </div>
      )}

      {/* Engine Selector */}
      <div className="mb-5">
        <label className="block text-xs text-gray-400 font-mono mb-2">motor_ia // engine selector</label>
        <div className="space-y-2">
          {ENGINES.map((eng) => (
            <button
              key={eng.key}
              onClick={() => setEngine(eng.key)}
              className={`w-full flex items-center justify-between p-3 rounded-lg border transition-all text-left ${
                engine === eng.key
                  ? 'border-cyber-violet bg-cyber-violet/10'
                  : 'border-white/5 bg-deep-space hover:border-white/10'
              }`}
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className={`text-sm font-semibold ${engine === eng.key ? 'text-ghost-white' : 'text-gray-400'}`}>
                    {eng.name}
                  </span>
                  {eng.badge && (
                    <span className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                      eng.badge === 'RECOMMENDED'
                        ? 'bg-neon-lime/10 text-neon-lime border border-neon-lime/20'
                        : 'bg-electric-cyan/10 text-electric-cyan border border-electric-cyan/20'
                    }`}>
                      {eng.badge}
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-gray-500 mt-0.5 font-mono">{eng.desc}</p>
              </div>
              <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                engine === eng.key ? 'border-neon-lime' : 'border-gray-600'
              }`}>
                {engine === eng.key && <div className="w-2 h-2 rounded-full bg-neon-lime" />}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Material Selector */}
      <div className="mb-5">
        <label className="block text-xs text-gray-400 font-mono mb-2">material // filament config</label>
        <select
          value={material}
          onChange={(e) => setMaterial(e.target.value)}
          className="w-full bg-deep-space border border-white/10 rounded-lg p-3 text-sm text-ghost-white focus:outline-none focus:border-cyber-violet font-mono appearance-none cursor-pointer"
          style={{ backgroundImage: 'none' }}
        >
          {MATERIALS.map((mat) => (
            <option key={mat.key} value={mat.key}>
              {mat.name} — R$ {mat.price}/kg // {mat.desc}
            </option>
          ))}
        </select>
      </div>

      {/* Layer Height */}
      <div className="mb-6">
        <label className="block text-xs text-gray-400 font-mono mb-2">
          layer_height // {layerHeight}mm
        </label>
        <input
          type="range"
          min="0.1"
          max="0.4"
          step="0.05"
          value={layerHeight}
          onChange={(e) => setLayerHeight(parseFloat(e.target.value))}
          className="w-full accent-neon-lime"
        />
        <div className="flex justify-between text-[10px] text-gray-600 font-mono mt-1">
          <span>0.1mm (fine)</span>
          <span>0.2mm (standard)</span>
          <span>0.4mm (draft)</span>
        </div>
      </div>

      {/* Error */}
      {error && (
        <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-xs text-red-400 font-mono">
          [ERROR] {error}
        </div>
      )}

      {/* Generate Button */}
      <button
        onClick={handleGenerate}
        disabled={isLoading}
        className="w-full py-4 rounded-lg font-bold text-sm font-mono tracking-wider relative overflow-hidden transition-all disabled:opacity-50 disabled:cursor-not-allowed bg-holo-gradient text-white hover:opacity-90"
      >
        {isLoading ? (
          <span className="flex items-center justify-center gap-2">
            <Sparkles size={16} className="animate-spin" />
            PROCESSANDO...
          </span>
        ) : (
          <span className="flex items-center justify-center gap-2">
            <Sparkles size={16} />
            ⚡ EXECUTE GENERATION
          </span>
        )}
      </button>
    </div>
  );
}
