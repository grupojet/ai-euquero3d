import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'euquero3d — AI Platform',
  description: 'Geração de modelos 3D por Inteligência Artificial. Texto e imagem → STL pronto para impressão.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR">
      <body className="antialiased min-h-screen bg-deep-space text-ghost-white">
        <div className="scanline-overlay" />
        {children}
      </body>
    </html>
  );
}
