/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        'deep-space': '#0A0A0F',
        'deep-space-2': '#12121A',
        'cyber-violet': '#7C3AED',
        'neon-lime': '#C6F432',
        'electric-cyan': '#22D3EE',
        'ghost-white': '#E5E5F0',
      },
      fontFamily: {
        display: ['Space Grotesk', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
        body: ['Inter', 'system-ui', 'sans-serif'],
      },
      backgroundImage: {
        'holo-gradient': 'linear-gradient(135deg, #7C3AED 0%, #22D3EE 100%)',
      },
    },
  },
  plugins: [],
};
