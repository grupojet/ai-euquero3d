from pydantic_settings import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    APP_NAME: str = "euquero3d-ai-platform"
    VERSION: str = "2.0.0"

    # Database
    DATABASE_URL: str = "postgresql://euquero3d:e3d_secure_2026@postgres:5432/euquero3d_ai"

    # Redis
    REDIS_URL: str = "redis://redis:6379/0"

    # MinIO
    MINIO_ENDPOINT: str = "minio:9000"
    MINIO_ACCESS_KEY: str = "euquero3d"
    MINIO_SECRET_KEY: str = "e3d_minio_2026"
    MINIO_SECURE: bool = False

    # Security
    SECRET_KEY: str = "euquero3d_super_secret_key_change_me"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 dias

    # Worker
    WORKER_TIMEOUT: int = 600

    # Storage
    UPLOAD_BUCKET: str = "euquero3d-uploads"
    OUTPUT_BUCKET: str = "euquero3d-outputs"

    class Config:
        env_file = ".env"

@lru_cache()
def get_settings() -> Settings:
    return Settings()
