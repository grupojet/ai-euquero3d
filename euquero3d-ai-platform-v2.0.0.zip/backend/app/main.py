from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager

from app.core.database import engine, Base
from app.api import jobs, upload

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    # Shutdown
    await engine.dispose()

app = FastAPI(
    title="EUQUERO3D AI Platform",
    description="Plataforma de geração 3D por IA — self-hosted, open-source",
    version="2.0.0",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Em produção, restrinja ao domínio do frontend
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routes
app.include_router(jobs.router)
app.include_router(upload.router)

@app.get("/health")
async def health_check():
    return {"status": "ok", "version": "2.0.0", "brand": "euquero3d"}

@app.get("/")
async def root():
    return {
        "message": "euquero3d AI Platform API",
        "docs": "/docs",
        "version": "2.0.0",
        "tagline": "from desire to reality",
    }
