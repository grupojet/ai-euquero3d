from sqlalchemy import Column, Integer, String, Float, DateTime, JSON, Text, Enum
from sqlalchemy.sql import func
from app.core.database import Base
import enum

class JobStatus(str, enum.Enum):
    PENDING = "pending"
    QUEUED = "queued"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class JobType(str, enum.Enum):
    TEXT_TO_3D = "text_to_3d"
    IMAGE_TO_3D = "image_to_3d"

class Job(Base):
    __tablename__ = "jobs"

    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(String(64), unique=True, index=True, nullable=False)
    job_type = Column(Enum(JobType), nullable=False)
    status = Column(Enum(JobStatus), default=JobStatus.PENDING)

    # Input
    prompt = Column(Text, nullable=True)
    input_image_url = Column(String(512), nullable=True)

    # Config
    engine = Column(String(32), default="hunyuan3d")  # hunyuan3d, triposr
    material = Column(String(16), default="pla")
    layer_height = Column(Float, default=0.2)

    # Output
    output_mesh_url = Column(String(512), nullable=True)
    output_stl_url = Column(String(512), nullable=True)
    output_preview_url = Column(String(512), nullable=True)

    # Analysis
    volume_cm3 = Column(Float, nullable=True)
    filament_grams = Column(Float, nullable=True)
    print_time_hours = Column(Float, nullable=True)
    cost_material = Column(Float, nullable=True)
    cost_machine = Column(Float, nullable=True)
    cost_total = Column(Float, nullable=True)

    # Metadata
    metadata_json = Column(JSON, default=dict)
    error_message = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    completed_at = Column(DateTime(timezone=True), nullable=True)
