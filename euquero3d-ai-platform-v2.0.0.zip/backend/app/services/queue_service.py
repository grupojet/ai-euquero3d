import redis
import json
import uuid
from typing import Optional
from app.core.config import get_settings

settings = get_settings()

class QueueService:
    def __init__(self):
        self.redis_client = redis.from_url(settings.REDIS_URL, decode_responses=True)
        self.queue_name = "e3d:generation:queue"
        self.progress_prefix = "e3d:progress:"

    def enqueue_job(self, job_data: dict) -> str:
        job_id = str(uuid.uuid4())
        job_data["job_id"] = job_id
        self.redis_client.lpush(self.queue_name, json.dumps(job_data))
        self._set_progress(job_id, {"status": "queued", "progress": 0})
        return job_id

    def get_progress(self, job_id: str) -> Optional[dict]:
        data = self.redis_client.get(f"{self.progress_prefix}{job_id}")
        return json.loads(data) if data else None

    def _set_progress(self, job_id: str, progress: dict):
        self.redis_client.setex(
            f"{self.progress_prefix}{job_id}",
            3600,  # 1h TTL
            json.dumps(progress)
        )

    def publish_progress(self, job_id: str, progress: dict):
        self._set_progress(job_id, progress)
        self.redis_client.publish(f"e3d:channel:{job_id}", json.dumps(progress))

queue_service = QueueService()
