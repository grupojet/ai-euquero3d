from minio import Minio
from minio.error import S3Error
from app.core.config import get_settings
import io

settings = get_settings()

class MinioService:
    def __init__(self):
        self.client = Minio(
            settings.MINIO_ENDPOINT,
            access_key=settings.MINIO_ACCESS_KEY,
            secret_key=settings.MINIO_SECRET_KEY,
            secure=settings.MINIO_SECURE,
        )
        self._ensure_buckets()

    def _ensure_buckets(self):
        for bucket in [settings.UPLOAD_BUCKET, settings.OUTPUT_BUCKET]:
            if not self.client.bucket_exists(bucket):
                self.client.make_bucket(bucket)

    def upload_file(self, bucket: str, object_name: str, data: bytes, content_type: str = "application/octet-stream") -> str:
        self.client.put_object(
            bucket,
            object_name,
            io.BytesIO(data),
            length=len(data),
            content_type=content_type,
        )
        return f"/{bucket}/{object_name}"

    def get_presigned_url(self, bucket: str, object_name: str, expires: int = 3600) -> str:
        return self.client.presigned_get_object(bucket, object_name, expires)

    def download_file(self, bucket: str, object_name: str) -> bytes:
        response = self.client.get_object(bucket, object_name)
        return response.read()

minio_service = MinioService()
