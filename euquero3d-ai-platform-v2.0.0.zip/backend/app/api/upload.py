from fastapi import APIRouter, UploadFile, File, HTTPException
from app.services.minio_service import minio_service
from app.core.config import get_settings
import uuid

router = APIRouter(prefix="/api/v1/upload", tags=["upload"])
settings = get_settings()

ALLOWED_TYPES = {"image/jpeg", "image/png", "image/webp", "image/jpg"}
MAX_SIZE = 10 * 1024 * 1024  # 10MB

@router.post("/image")
async def upload_image(file: UploadFile = File(...)):
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(status_code=400, detail="Tipo de arquivo não suportado. Use JPG, PNG ou WEBP.")

    contents = await file.read()
    if len(contents) > MAX_SIZE:
        raise HTTPException(status_code=400, detail="Arquivo muito grande. Máximo 10MB.")

    ext = file.filename.split(".")[-1].lower()
    object_name = f"uploads/{uuid.uuid4()}.{ext}"

    url = minio_service.upload_file(
        settings.UPLOAD_BUCKET,
        object_name,
        contents,
        content_type=file.content_type,
    )

    return {
        "filename": file.filename,
        "url": url,
        "object_name": object_name,
        "size": len(contents),
    }
