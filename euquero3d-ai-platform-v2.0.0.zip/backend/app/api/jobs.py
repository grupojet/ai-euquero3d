from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import Optional
from app.core.database import get_db
from app.models.job import Job, JobStatus, JobType
from app.services.queue_service import queue_service
from app.services.minio_service import minio_service
from pydantic import BaseModel
import uuid

router = APIRouter(prefix="/api/v1/jobs", tags=["jobs"])

class TextTo3DRequest(BaseModel):
    prompt: str
    engine: str = "hunyuan3d"  # hunyuan3d, triposr
    material: str = "pla"
    layer_height: float = 0.2

class ImageTo3DRequest(BaseModel):
    image_url: str
    engine: str = "hunyuan3d"
    material: str = "pla"
    layer_height: float = 0.2

class JobResponse(BaseModel):
    job_id: str
    status: str
    progress: Optional[dict] = None

    class Config:
        from_attributes = True

@router.post("/text-to-3d", response_model=JobResponse)
async def create_text_to_3d(
    request: TextTo3DRequest,
    db: AsyncSession = Depends(get_db)
):
    job_id = str(uuid.uuid4())

    # Criar registro no banco
    job = Job(
        job_id=job_id,
        job_type=JobType.TEXT_TO_3D,
        status=JobStatus.QUEUED,
        prompt=request.prompt,
        engine=request.engine,
        material=request.material,
        layer_height=request.layer_height,
    )
    db.add(job)
    await db.commit()

    # Enfileirar no Redis
    queue_service.enqueue_job({
        "job_id": job_id,
        "job_type": "text_to_3d",
        "prompt": request.prompt,
        "engine": request.engine,
        "material": request.material,
        "layer_height": request.layer_height,
    })

    return JobResponse(job_id=job_id, status="queued")

@router.post("/image-to-3d", response_model=JobResponse)
async def create_image_to_3d(
    request: ImageTo3DRequest,
    db: AsyncSession = Depends(get_db)
):
    job_id = str(uuid.uuid4())

    job = Job(
        job_id=job_id,
        job_type=JobType.IMAGE_TO_3D,
        status=JobStatus.QUEUED,
        input_image_url=request.image_url,
        engine=request.engine,
        material=request.material,
        layer_height=request.layer_height,
    )
    db.add(job)
    await db.commit()

    queue_service.enqueue_job({
        "job_id": job_id,
        "job_type": "image_to_3d",
        "image_url": request.image_url,
        "engine": request.engine,
        "material": request.material,
        "layer_height": request.layer_height,
    })

    return JobResponse(job_id=job_id, status="queued")

@router.get("/{job_id}", response_model=JobResponse)
async def get_job(job_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Job).where(Job.job_id == job_id))
    job = result.scalar_one_or_none()

    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    progress = queue_service.get_progress(job_id)

    return JobResponse(
        job_id=job.job_id,
        status=job.status.value,
        progress=progress,
    )

@router.get("/{job_id}/result")
async def get_job_result(job_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Job).where(Job.job_id == job_id))
    job = result.scalar_one_or_none()

    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    if job.status != JobStatus.COMPLETED:
        raise HTTPException(status_code=400, detail="Job not completed yet")

    return {
        "job_id": job.job_id,
        "status": job.status.value,
        "output_mesh_url": job.output_mesh_url,
        "output_stl_url": job.output_stl_url,
        "output_preview_url": job.output_preview_url,
        "volume_cm3": job.volume_cm3,
        "filament_grams": job.filament_grams,
        "print_time_hours": job.print_time_hours,
        "cost_material": job.cost_material,
        "cost_machine": job.cost_machine,
        "cost_total": job.cost_total,
    }
