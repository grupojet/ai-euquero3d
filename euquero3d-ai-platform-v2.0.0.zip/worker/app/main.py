#!/usr/bin/env python3
"""
EUQUERO3D AI Worker — Motor de Inferência 3D
Consumes jobs from Redis, runs AI inference, post-processes, uploads to MinIO.

Architecture:
  Redis Queue → Worker → Hunyuan3D/TripoSR → PostProcess → MinIO → PostgreSQL
"""

import os
import sys
import json
import time
import tempfile
import shutil
from pathlib import Path
from datetime import datetime

import redis
import requests
from minio import Minio

# Pipeline modules
from app.pipeline.hunyuan3d import Hunyuan3DEngine
from app.pipeline.triposr import TripoSREngine
from app.pipeline.postprocess import process_mesh
from app.pipeline.pricing import calculate_quote

# ── Config ──
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")
MINIO_ENDPOINT = os.getenv("MINIO_ENDPOINT", "minio:9000")
MINIO_ACCESS_KEY = os.getenv("MINIO_ACCESS_KEY", "euquero3d")
MINIO_SECRET_KEY = os.getenv("MINIO_SECRET_KEY", "e3d_minio_2026")
API_BASE_URL = os.getenv("API_BASE_URL", "http://backend:8000")
WORKER_CONCURRENCY = int(os.getenv("WORKER_CONCURRENCY", "1"))
QUEUE_NAME = "e3d:generation:queue"
PROGRESS_PREFIX = "e3d:progress:"
DL_PREFIX = "e3d:download:"

# ── Engines (lazy load) ──
_engines = {}

def get_engine(engine_name: str):
    """Lazy-load AI engines."""
    if engine_name not in _engines:
        if engine_name == "hunyuan3d":
            _engines[engine_name] = Hunyuan3DEngine()
        elif engine_name == "triposr":
            _engines[engine_name] = TripoSREngine()
        else:
            # Default to Hunyuan3D
            _engines[engine_name] = Hunyuan3DEngine()
    return _engines[engine_name]

# ── Redis ──
redis_client = redis.from_url(REDIS_URL, decode_responses=True)

# ── MinIO ──
minio_client = Minio(
    MINIO_ENDPOINT,
    access_key=MINIO_ACCESS_KEY,
    secret_key=MINIO_SECRET_KEY,
    secure=False,
)

def ensure_buckets():
    for bucket in ["euquero3d-uploads", "euquero3d-outputs"]:
        if not minio_client.bucket_exists(bucket):
            minio_client.make_bucket(bucket)

# ── Progress Tracking ──
def set_progress(job_id: str, data: dict):
    redis_client.setex(f"{PROGRESS_PREFIX}{job_id}", 3600, json.dumps(data))
    # Publish to channel for WebSocket streaming
    redis_client.publish(f"e3d:channel:{job_id}", json.dumps(data))

def update_job_db(job_id: str, updates: dict):
    """Update job status in backend via REST API."""
    try:
        resp = requests.patch(
            f"{API_BASE_URL}/api/v1/jobs/{job_id}/internal-update",
            json=updates,
            timeout=10,
        )
        if resp.status_code != 200:
            print(f"[WARN] Failed to update job DB: {resp.text}")
    except Exception as e:
        print(f"[WARN] DB update error: {e}")

# ── Job Processing ──
def process_job(job_data: dict):
    job_id = job_data["job_id"]
    job_type = job_data["job_type"]
    engine_name = job_data.get("engine", "hunyuan3d")
    material = job_data.get("material", "pla")
    layer_height = job_data.get("layer_height", 0.2)

    work_dir = tempfile.mkdtemp(prefix=f"e3d_{job_id}_")

    try:
        print(f"\n{'='*60}")
        print(f"[JOB {job_id}] Type: {job_type} | Engine: {engine_name}")
        print(f"{'='*60}")

        set_progress(job_id, {
            "status": "processing",
            "stage": "loading_model",
            "progress": 5,
            "message": "Carregando modelo de IA...",
        })

        # Load engine
        engine = get_engine(engine_name)
        engine.load()

        set_progress(job_id, {
            "status": "processing",
            "stage": "inference",
            "progress": 15,
            "message": "Gerando modelo 3D com IA...",
        })

        # Run inference
        if job_type == "text_to_3d":
            prompt = job_data.get("prompt", "")
            mesh_path, meta = engine.generate_from_text(prompt)

        elif job_type == "image_to_3d":
            image_url = job_data.get("image_url", "")
            # Download image from MinIO
            parts = image_url.strip("/").split("/")
            bucket = parts[0]
            object_name = "/".join(parts[1:])

            local_image = os.path.join(work_dir, "input.png")
            minio_client.fget_object(bucket, object_name, local_image)

            mesh_path, meta = engine.generate_from_image(local_image)
        else:
            raise ValueError(f"Unknown job type: {job_type}")

        set_progress(job_id, {
            "status": "processing",
            "stage": "postprocess",
            "progress": 60,
            "message": "Pós-processando mesh...",
        })

        # Post-process
        pp_result = process_mesh(mesh_path, work_dir)

        set_progress(job_id, {
            "status": "processing",
            "stage": "analysis",
            "progress": 80,
            "message": "Calculando volume e orçamento...",
        })

        # Calculate pricing
        volume = pp_result.get("volume_cm3", 0.0)
        if volume <= 0 and pp_result.get("is_watertight"):
            # Fallback volume estimation
            volume = pp_result.get("face_count", 1000) * 0.01

        quote = calculate_quote(volume, material, layer_height)

        # Upload outputs to MinIO
        output_files = {}

        if pp_result.get("stl_path") and os.path.exists(pp_result["stl_path"]):
            stl_obj = f"outputs/{job_id}/model.stl"
            minio_client.fput_object(
                "euquero3d-outputs",
                stl_obj,
                pp_result["stl_path"],
                content_type="model/stl",
            )
            output_files["stl"] = f"/euquero3d-outputs/{stl_obj}"

        if pp_result.get("preview_path") and os.path.exists(pp_result["preview_path"]):
            preview_obj = f"outputs/{job_id}/preview.png"
            minio_client.fput_object(
                "euquero3d-outputs",
                preview_obj,
                pp_result["preview_path"],
                content_type="image/png",
            )
            output_files["preview"] = f"/euquero3d-outputs/{preview_obj}"

        # Also upload original mesh if available
        if mesh_path and os.path.exists(mesh_path):
            mesh_obj = f"outputs/{job_id}/model.glb"
            minio_client.fput_object(
                "euquero3d-outputs",
                mesh_obj,
                mesh_path,
                content_type="model/gltf-binary",
            )
            output_files["mesh"] = f"/euquero3d-outputs/{mesh_obj}"

        set_progress(job_id, {
            "status": "completed",
            "stage": "done",
            "progress": 100,
            "message": "Concluído! Modelo pronto para impressão.",
            "outputs": output_files,
            "metrics": {
                "volume_cm3": quote["volume_cm3"],
                "filament_grams": quote["filament_grams"],
                "print_time_hours": quote["print_time_hours"],
                "print_time_formatted": quote["print_time_formatted"],
                "cost_material": quote["cost_material"],
                "cost_machine": quote["cost_machine"],
                "cost_total": quote["cost_total"],
                "price_sell": quote["price_sell"],
            },
            "mesh_info": {
                "faces": pp_result.get("face_count", 0),
                "vertices": pp_result.get("vertex_count", 0),
                "watertight": pp_result.get("is_watertight", False),
            },
        })

        print(f"[JOB {job_id}] ✅ COMPLETED")
        print(f"  Volume: {quote['volume_cm3']} cm³")
        print(f"  Filamento: {quote['filament_grams']}g")
        print(f"  Custo: R$ {quote['cost_total']}")
        print(f"  Preço venda: R$ {quote['price_sell']}")

    except Exception as e:
        print(f"[JOB {job_id}] ❌ FAILED: {e}")
        import traceback
        traceback.print_exc()

        set_progress(job_id, {
            "status": "failed",
            "stage": "error",
            "progress": 0,
            "message": f"Erro: {str(e)}",
            "error": str(e),
        })

    finally:
        # Cleanup
        if os.path.exists(work_dir):
            shutil.rmtree(work_dir, ignore_errors=True)

# ── Main Loop ──
def main():
    print("\n" + "="*60)
    print("  EUQUERO3D AI WORKER v2.0.0")
    print("  from desire to reality ▮")
    print("="*60)
    print(f"  Redis: {REDIS_URL}")
    print(f"  MinIO: {MINIO_ENDPOINT}")
    print(f"  API: {API_BASE_URL}")
    print(f"  Concurrency: {WORKER_CONCURRENCY}")
    print("="*60 + "\n")

    ensure_buckets()

    print("[WORKER] Aguardando jobs...")

    while True:
        try:
            # Blocking pop from queue (wait indefinitely)
            result = redis_client.brpop(QUEUE_NAME, timeout=5)

            if result is None:
                continue

            _, job_json = result
            job_data = json.loads(job_json)

            process_job(job_data)

        except KeyboardInterrupt:
            print("\n[WORKER] Encerrando graciosamente...")
            break
        except Exception as e:
            print(f"[WORKER] Erro no loop principal: {e}")
            time.sleep(5)

if __name__ == "__main__":
    main()
