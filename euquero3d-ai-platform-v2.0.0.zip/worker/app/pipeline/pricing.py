"""
Módulo de cálculo de orçamento para impressão 3D.
Integrado à identidade euquero3d — precisão maker, transparência total.
"""

MATERIALS = {
    "pla": {"name": "PLA", "price_kg": 85.0, "density": 1.24, "color": "#C6F432"},
    "abs": {"name": "ABS", "price_kg": 95.0, "density": 1.04, "color": "#22D3EE"},
    "petg": {"name": "PETG", "price_kg": 110.0, "density": 1.27, "color": "#7C3AED"},
    "tpu": {"name": "TPU", "price_kg": 150.0, "density": 1.21, "color": "#E5E5F0"},
    "resina": {"name": "Resina", "price_kg": 280.0, "density": 1.10, "color": "#22D3EE"},
}

MACHINE_RATE_PER_HOUR = 8.0  # R$/h — custo de máquina + energia + manutenção
POST_PROCESS_RATE = 0.15     # 15% sobre custo de material

def calculate_quote(volume_cm3: float, material_key: str, layer_height: float = 0.2) -> dict:
    """
    Calcula orçamento completo de impressão 3D.

    Args:
        volume_cm3: Volume do modelo em cm³
        material_key: Chave do material (pla, abs, petg, tpu, resina)
        layer_height: Altura de camada em mm

    Returns:
        dict com todos os custos e métricas
    """
    mat = MATERIALS.get(material_key, MATERIALS["pla"])

    # Cálculos físicos
    grams = volume_cm3 * mat["density"]

    # Tempo estimado: fator base + variação por volume
    # FDM: ~15 cm³/h em qualidade padrão
    print_speed_cm3_h = 15.0 if layer_height <= 0.2 else 22.0
    hours = volume_cm3 / print_speed_cm3_h
    hours = max(hours, 0.5)  # Mínimo 30 min

    # Custos
    cost_material = (grams / 1000) * mat["price_kg"]
    cost_machine = hours * MACHINE_RATE_PER_HOUR
    cost_post = cost_material * POST_PROCESS_RATE
    cost_total = cost_material + cost_machine + cost_post

    # Margem sugerida (para venda)
    margin = 0.60
    price_sell = cost_total * (1 + margin)

    return {
        "material": mat["name"],
        "material_color": mat["color"],
        "volume_cm3": round(volume_cm3, 2),
        "filament_grams": round(grams, 1),
        "layer_height_mm": layer_height,
        "print_time_hours": round(hours, 1),
        "print_time_formatted": _format_time(hours),
        "cost_material": round(cost_material, 2),
        "cost_machine": round(cost_machine, 2),
        "cost_post_process": round(cost_post, 2),
        "cost_total": round(cost_total, 2),
        "price_sell": round(price_sell, 2),
        "margin_percent": int(margin * 100),
    }

def _format_time(hours: float) -> str:
    h = int(hours)
    m = int((hours - h) * 60)
    if h > 0:
        return f"{h}h {m}min"
    return f"{m}min"

def get_materials_catalog() -> list:
    """Retorna catálogo de materiais para o frontend."""
    return [
        {
            "key": k,
            "name": v["name"],
            "price_kg": v["price_kg"],
            "density": v["density"],
            "color": v["color"],
        }
        for k, v in MATERIALS.items()
    ]
