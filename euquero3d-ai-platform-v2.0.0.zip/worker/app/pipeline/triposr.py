"""
Wrapper para TripoSR (Stability AI / VAST AI).
Motor rápido de image-to-3D — ideal para drafts e previews.
Roda em GPUs modestas (6-8GB VRAM).
"""

import os
import sys
import torch
import numpy as np
from pathlib import Path
from PIL import Image
from typing import Tuple

TRIPOSR_PATH = "/models/triposr"
if os.path.exists(TRIPOSR_PATH):
    sys.path.insert(0, TRIPOSR_PATH)

class TripoSREngine:
    """
    Motor rápido de image-to-3D.
    Sub-segundo em hardware modesto.
    """

    def __init__(self, device: str = "cuda", cache_dir: str = "/models/cache"):
        self.device = device if torch.cuda.is_available() else "cpu"
        self.cache_dir = cache_dir
        self.model = None
        self._loaded = False

    def load(self):
        if self._loaded:
            return

        print(f"[TripoSR] Carregando modelo em {self.device}...")

        try:
            from tsr.system import TSR

            self.model = TSR.from_pretrained(
                "stabilityai/TripoSR",
                config_name="config.yaml",
                weight_name="model.ckpt",
                cache_dir=self.cache_dir,
            )
            self.model.renderer.set_chunk_size(8192)
            self.model.to(self.device)
            self._loaded = True
            print("[TripoSR] Modelo carregado com sucesso!")

        except ImportError as e:
            print(f"[TripoSR] Import error: {e}")
            print("[TripoSR] TripoSR não disponível nesta build.")
            self.model = None
            self._loaded = True  # Marca como loaded para não tentar de novo
        except Exception as e:
            print(f"[TripoSR] Erro ao carregar: {e}")
            self.model = None
            self._loaded = True

    def generate_from_image(
        self,
        image_path: str,
        mc_resolution: int = 256,
        remove_bg: bool = True,
    ) -> Tuple[str, dict]:
        """
        Gera mesh 3D a partir de imagem em ~1 segundo.

        Returns:
            (mesh_path, metadata)
        """
        self.load()

        if self.model is None:
            raise RuntimeError("TripoSR não disponível. Use Hunyuan3D.")

        print(f"[TripoSR] Processing image: {image_path}")

        # Carrega e preprocessa imagem
        image = Image.open(image_path).convert("RGB")

        if remove_bg:
            try:
                from rembg import remove
                image = remove(image)
                # Converter para RGB (rembg retorna RGBA)
                background = Image.new('RGB', image.size, (255, 255, 255))
                background.paste(image, mask=image.split()[3] if image.mode == 'RGBA' else None)
                image = background
            except Exception as e:
                print(f"[TripoSR] rembg falhou: {e}, usando imagem original")

        # Inference
        with torch.no_grad():
            scene_codes = self.model(image, device=self.device)
            meshes = self.model.extract_mesh(scene_codes, resolution=mc_resolution)

        # Salva primeira mesh
        mesh = meshes[0]
        output_path = "/tmp/triposr_output.obj"
        mesh.export(output_path)

        return output_path, {
            "engine": "triposr",
            "mode": "image_to_3d",
            "mc_resolution": mc_resolution,
            "faces": len(mesh.faces),
            "vertices": len(mesh.vertices),
        }
