"""
Pipeline de pós-processamento 3D.
Converte malhas para STL pronto para impressão, calcula volume,
gera suportes e cria previews.
"""

import os
import tempfile
import numpy as np
from pathlib import Path

try:
    import trimesh
    HAS_TRIMESH = True
except ImportError:
    HAS_TRIMESH = False

try:
    import pymeshlab
    HAS_MESHLAB = True
except ImportError:
    HAS_MESHLAB = False

def process_mesh(input_path: str, output_dir: str, target_faces: int = 50000) -> dict:
    """
    Pipeline completo de pós-processamento:
    1. Carrega mesh (GLB/OBJ/PLY)
    2. Verifica watertight
    3. Decimation (redução de polígonos)
    4. Exporta STL
    5. Calcula volume
    6. Gera preview PNG

    Returns:
        dict com paths dos arquivos de saída e métricas
    """
    result = {
        "stl_path": None,
        "preview_path": None,
        "volume_cm3": None,
        "is_watertight": False,
        "face_count": 0,
        "vertex_count": 0,
    }

    if not HAS_TRIMESH:
        print("[WARN] trimesh não disponível. Usando fallback.")
        return result

    # Carregar mesh
    mesh = trimesh.load(input_path, force='mesh')

    if mesh is None or len(mesh.faces) == 0:
        print("[ERROR] Mesh vazio ou inválido")
        return result

    # Métricas
    result["face_count"] = len(mesh.faces)
    result["vertex_count"] = len(mesh.vertices)
    result["is_watertight"] = mesh.is_watertight
    result["volume_cm3"] = float(mesh.volume) / 1000.0 if mesh.is_watertight else 0.0

    # Reparar se não for watertight
    if not mesh.is_watertight:
        print("[INFO] Reparando mesh (fill holes)...")
        mesh = mesh.fill_holes()
        mesh = mesh.merge_vertices()
        result["is_watertight"] = mesh.is_watertight
        if mesh.is_watertight:
            result["volume_cm3"] = float(mesh.volume) / 1000.0

    # Decimation se necessário
    if len(mesh.faces) > target_faces:
        print(f"[INFO] Decimating from {len(mesh.faces)} to ~{target_faces} faces...")
        mesh = mesh.simplify_quadric_decimation(target_faces)
        result["face_count"] = len(mesh.faces)
        result["vertex_count"] = len(mesh.vertices)

    # Exportar STL
    os.makedirs(output_dir, exist_ok=True)
    stl_path = os.path.join(output_dir, "model.stl")
    mesh.export(stl_path)
    result["stl_path"] = stl_path

    # Gerar preview (render simples)
    preview_path = os.path.join(output_dir, "preview.png")
    _generate_preview(mesh, preview_path)
    result["preview_path"] = preview_path

    return result

def _generate_preview(mesh, output_path: str):
    """Gera uma imagem preview da mesh usando trimesh."""
    try:
        # Tentar usar o render do trimesh (requer pyglet/PIL)
        scene = mesh.scene()
        png = scene.save_image(resolution=[512, 512])
        if png:
            with open(output_path, 'wb') as f:
                f.write(png)
    except Exception as e:
        print(f"[WARN] Preview render failed: {e}")
        # Fallback: criar imagem placeholder
        try:
            from PIL import Image, ImageDraw, ImageFont
            img = Image.new('RGB', (512, 512), color=(10, 10, 15))
            draw = ImageDraw.Draw(img)
            draw.text((180, 240), "euquero3d", fill=(198, 244, 50))
            draw.text((160, 270), "preview_3d", fill=(124, 58, 237))
            img.save(output_path)
        except Exception:
            pass

def generate_supports(mesh_path: str, output_path: str, overhang_angle: float = 45.0):
    """
    Gera estruturas de suporte para impressão FDM.
    Simplificado — em produção, usar CuraEngine ou PrusaSlicer CLI.
    """
    # Placeholder: em produção, integrar com:
    # - CuraEngine (command line)
    # - PrusaSlicer (command line)  
    # - custom support generator
    print(f"[INFO] Support generation requested for {mesh_path}")
    print(f"[INFO] Output would be: {output_path}")
    return None
