"""
Wrapper para Hunyuan3D-2 (Tencent).
Motor principal de geração 3D — text-to-3D e image-to-3D.
"""

import os
import sys
import torch
import numpy as np
from pathlib import Path
from PIL import Image
from typing import Optional, Tuple

# Adicionar o repo do Hunyuan3D ao path
HUNYUAN3D_PATH = "/models/hunyuan3d2"
if os.path.exists(HUNYUAN3D_PATH):
    sys.path.insert(0, HUNYUAN3D_PATH)

class Hunyuan3DEngine:
    """
    Motor de geração 3D baseado no Hunyuan3D-2.
    Suporta text-to-3D e image-to-3D.
    """

    def __init__(self, device: str = "cuda", cache_dir: str = "/models/cache"):
        self.device = device if torch.cuda.is_available() else "cpu"
        self.cache_dir = cache_dir
        self.pipeline = None
        self._loaded = False

    def load(self):
        """Carrega o pipeline do Hunyuan3D-2."""
        if self._loaded:
            return

        print(f"[Hunyuan3D] Carregando modelo em {self.device}...")
        print(f"[Hunyuan3D] Cache: {self.cache_dir}")

        try:
            # Tentar importar o pipeline oficial
            from hy3dgen.shapegen import HunyuanDiTPipeline, FaceReducer, FloaterRemover, DegenerateFaceRemover
            from hy3dgen.texgen import HunyuanPaintPipeline

            # Pipeline de geração de forma
            self.shape_pipeline = HunyuanDiTPipeline.from_pretrained(
                'tencent/Hunyuan3D-2',
                variant='fp16',
                torch_dtype=torch.float16,
                cache_dir=self.cache_dir,
            )
            self.shape_pipeline.to(self.device)

            # Pipeline de texturização
            self.tex_pipeline = HunyuanPaintPipeline.from_pretrained(
                'tencent/Hunyuan3D-2',
                variant='fp16',
                torch_dtype=torch.float16,
                cache_dir=self.cache_dir,
            )
            self.tex_pipeline.to(self.device)

            # Pós-processadores
            self.face_reducer = FaceReducer()
            self.floater_remover = FloaterRemover()
            self.degenerate_remover = DegenerateFaceRemover()

            self._loaded = True
            print("[Hunyuan3D] Modelo carregado com sucesso!")

        except ImportError as e:
            print(f"[Hunyuan3D] Import error: {e}")
            print("[Hunyuan3D] Usando modo fallback (diffusers + trimesh)")
            self._setup_fallback()
        except Exception as e:
            print(f"[Hunyuan3D] Erro ao carregar: {e}")
            self._setup_fallback()

    def _setup_fallback(self):
        """Setup fallback usando diffusers + reconstrução básica."""
        try:
            from diffusers import StableDiffusionPipeline
            self.fallback_pipe = StableDiffusionPipeline.from_pretrained(
                "stabilityai/stable-diffusion-2-1",
                torch_dtype=torch.float16,
                cache_dir=self.cache_dir,
            )
            self.fallback_pipe.to(self.device)
            self._loaded = True
            print("[Hunyuan3D] Fallback carregado (SD2.1)")
        except Exception as e:
            print(f"[Hunyuan3D] Fallback também falhou: {e}")
            self.fallback_pipe = None

    def generate_from_text(
        self,
        prompt: str,
        num_views: int = 4,
        num_inference_steps: int = 50,
        guidance_scale: float = 7.5,
    ) -> Tuple[str, dict]:
        """
        Gera modelo 3D a partir de texto.

        Returns:
            (mesh_path, metadata)
        """
        self.load()

        if not self._loaded:
            raise RuntimeError("Modelo não carregado")

        print(f"[Hunyuan3D] Generating from text: '{prompt[:60]}...'")

        # Se tiver pipeline oficial
        if hasattr(self, 'shape_pipeline') and self.shape_pipeline is not None:
            try:
                # Gera mesh
                mesh = self.shape_pipeline(
                    prompt,
                    num_inference_steps=num_inference_steps,
                    guidance_scale=guidance_scale,
                )[0]

                # Pós-processa
                mesh = self.floater_remover(mesh)
                mesh = self.degenerate_remover(mesh)
                mesh = self.face_reducer(mesh, max_facenum=40000)

                # Texturiza
                mesh = self.tex_pipeline(mesh, prompt)

                # Salva
                output_path = "/tmp/hunyuan_output.glb"
                mesh.export(output_path)

                return output_path, {
                    "engine": "hunyuan3d",
                    "mode": "text_to_3d",
                    "prompt": prompt,
                    "faces": len(mesh.faces),
                    "vertices": len(mesh.vertices),
                }
            except Exception as e:
                print(f"[Hunyuan3D] Pipeline oficial falhou: {e}")
                return self._fallback_text_to_3d(prompt)
        else:
            return self._fallback_text_to_3d(prompt)

    def generate_from_image(
        self,
        image_path: str,
        prompt: Optional[str] = None,
        num_inference_steps: int = 50,
    ) -> Tuple[str, dict]:
        """Gera modelo 3D a partir de imagem."""
        self.load()

        image = Image.open(image_path).convert("RGB")

        if hasattr(self, 'shape_pipeline') and self.shape_pipeline is not None:
            try:
                mesh = self.shape_pipeline(
                    image,
                    num_inference_steps=num_inference_steps,
                )[0]

                mesh = self.floater_remover(mesh)
                mesh = self.degenerate_remover(mesh)
                mesh = self.face_reducer(mesh, max_facenum=40000)

                if prompt:
                    mesh = self.tex_pipeline(mesh, prompt)

                output_path = "/tmp/hunyuan_output.glb"
                mesh.export(output_path)

                return output_path, {
                    "engine": "hunyuan3d",
                    "mode": "image_to_3d",
                    "faces": len(mesh.faces),
                    "vertices": len(mesh.vertices),
                }
            except Exception as e:
                print(f"[Hunyuan3D] Image pipeline falhou: {e}")
                return self._fallback_image_to_3d(image_path)
        else:
            return self._fallback_image_to_3d(image_path)

    def _fallback_text_to_3d(self, prompt: str) -> Tuple[str, dict]:
        """Fallback: gera imagem com SD, depois image-to-3D básico."""
        print("[Hunyuan3D] Usando fallback text-to-3D...")

        if self.fallback_pipe is None:
            raise RuntimeError("Nenhum pipeline disponível")

        # Gera imagem de referência
        image = self.fallback_pipe(
            prompt,
            num_inference_steps=30,
            guidance_scale=7.5,
        ).images[0]

        image_path = "/tmp/fallback_ref.png"
        image.save(image_path)

        return self._fallback_image_to_3d(image_path)

    def _fallback_image_to_3d(self, image_path: str) -> Tuple[str, dict]:
        """Fallback básico de image-to-3D usando trimesh primitives."""
        print("[Hunyuan3D] Fallback image-to-3D: criando mesh básica...")

        try:
            import trimesh
            # Criar um cubo como placeholder (em produção, usar InstantMesh ou similar)
            mesh = trimesh.creation.box(extents=[1, 1, 1])
            output_path = "/tmp/fallback_output.glb"
            mesh.export(output_path)

            return output_path, {
                "engine": "hunyuan3d_fallback",
                "mode": "fallback",
                "note": "Modelo oficial não disponível. Mesh placeholder gerada.",
                "faces": len(mesh.faces),
                "vertices": len(mesh.vertices),
            }
        except Exception as e:
            print(f"[Hunyuan3D] Fallback falhou: {e}")
            raise
